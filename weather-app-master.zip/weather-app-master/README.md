# weather-app
Weather Website using Node.js, Express, and OpenWeatherMap's API
1) Git clone of this repository
2) Execute npm install update the local node_modules repository with the versions present in package.json.
3) node server.js

Once server started, you might see the statment "Example app listening on port 3000!". 

Now open your browser and type localhost:3000, the weather app page will get displated. Type a city name into the field and hit enter! 
You should see the weather appear on your screen!